<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="initial-scale=1.0, user-scalable=no">
    <meta charset="utf-8">
    <title>TwittorMonitor</title>
    <link rel="stylesheet" type="text/css" href="index.css" />
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC5fwhqHz6t9wxInNrzyqfsPXwbyKQlYfQ&signed_in=true"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/d3/3.5.6/d3.min.js" charset="utf-8"></script>
    <script src="d3.layout.cloud.js"></script>
    <script src="index.js"></script>
</head>
<body>
  <div id="title">
    <div id="titleImage"></div>
    <div id="titleText">Twittor Monitor</div>
  </div>
  <div id="content">
    <div id="mapDiv">
      <div class="title">
        Map
      </div>
      <div id="map"></div>
    </div>
    <div id="rightColumn">
      <div id="TweetList" class="rightDiv">
        <div class="title">Tweet List</div>
        <div id="listContent" class="divContent"></div>
      </div>
      <div id="UserList" class="rightDiv">
        <div class="title">User List</div>
        <div class="divContent"></div>
      </div>
    </div>
  </div>
</body>
</html>
